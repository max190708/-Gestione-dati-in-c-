﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prima
{
    internal class Program
    {   
        //variabili globali
        struct Persona
        {
            public string nome;
            public int eta;
        }
        //funzioni
        static void Main(string[] args)
        {
            int a, b, c;
            string s;
            int[] arr;
            arr=new int[100];

            Persona[] persone;
            persone=new Persona[100];
            /* //inserimento del primo numero
             Console.WriteLine("inserisci il primo numero");
             s=Console.ReadLine();
             a = Convert.ToInt32(s);
             //inserimento del secondo numero
             Console.WriteLine("inserisci il secondo numero");
             b=Convert.ToInt32(Console.ReadLine());
             //elaborazione
             c=Somma(a, b);    
             //output
             Console.WriteLine(c);
            */
            /*Caricamento(arr, 5);
            int dimensione = 0;
            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine("inserisci l'elemento dell'array");
                b = Convert.ToInt32(Console.ReadLine());
                AddToArray(arr, b,ref dimensione);
            }
            Console.WriteLine(StampaArray(arr, dimensione));
            */
            int dimensione = 0;
            Persona p;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("inserisci il nome");
                p.nome=Console.ReadLine();
                Console.WriteLine("inserisci l'età");
                p.eta = Convert.ToInt32(Console.ReadLine());

                AddPersona(persone, p, ref dimensione);
            }
            Console.WriteLine(StampaElenco(persone, dimensione));


        }
        static int Somma(int a, int b)
        {
            int c;
            c = a + b;
            return c;
        }
        /*static void Caricamento(int[]x, int dim)
        {
            for (int i = 0; i < dim; i++)
            {
                Console.WriteLine("inserisci l'elemento");
                x[i] = Convert.ToInt32(Console.ReadLine());
            }    
        }
        */
        static void AddToArray(int[] arr,int ele, ref int dim)
        {
            arr[dim] = ele;
            dim++;
        }
        static string StampaArray(int[] z, int dim)
        {
            string s = "";   
            for (int i = 0;i < dim; i++)
            {
                s=s+z[i]+"\n";
            }
            return s;
        }
        static void AddPersona(Persona[]x,Persona p,ref int d)
        {
            x[d] = p;
            d++;    
        }
        static string StampaElenco(Persona[] x, int dim)
        {
            String s = "";
            for (int i = 0; i < dim; i++)
            {
                s = s + x[i].nome +"\t"+x[i].eta+ "\n";
            }
            return s;

        }

    }
}
